public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Nguyen Van Thai - 20215135"); // in ra màn hình dòng chữ trong dấu ngoặc kép
        System.out.println("Xin chao \n cac ban!");
        System.out.println("Hello \t world!");
    }
}
